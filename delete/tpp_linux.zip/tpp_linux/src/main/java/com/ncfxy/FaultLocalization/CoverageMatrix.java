package com.ncfxy.FaultLocalization;

public class CoverageMatrix {

}
