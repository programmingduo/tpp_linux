package cn.tjuscs.oj.testCases;

public class Main {
	
	public static void main(String[] args) {
//		System.out.println("Hello World!");
//		String str = "";
//		File file = new File("haha.txttt");
//		FileInputStream fileInputStream = null;
//		fileInputStream = new FileInputStream(file);
//		InputStreamReader reader = new InputStreamReader(fileInputStream);
//		// char[] cbuf = new char[10000];
//		// reader.read(cbuf);
//		// str = new String(cbuf);
//		// System.out.println(cbuf);
//		BufferedReader bufferReader = new BufferedReader(reader);
//		Scanner cin = new Scanner(fileInputStream);
//		while (cin.hasNext()) {
//
//		}
		
		SplitTestCases mySplit = null;
		
		
		mySplit.init("", "", "");
		mySplit.getSplitInputFilesResult();
		mySplit.getSplitOutputFilesResult();
	}

}
