package cn.tjuscs.oj.dividing;

import java.util.List;

public class SplitFile implements SplitTestCases {

	
	public void init(String inputFilePath, String outputFilePath, String rightProgramPath) {
		// TODO Auto-generated method stub
		
	}
	public List<String> getSplitInputFilesResult() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<String> getSplitOutputFilesResult() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
