using namespace std;
#include <cstdio>

int main()
{
	int cases,n,res;
	scanf("%d\n",&cases);
	while (cases--) {
		res=0;
		scanf("%d",&n);
		while ((n/=5)!=0) res+=n;
		printf("%d\n",res);
	}
	return 0;
}
