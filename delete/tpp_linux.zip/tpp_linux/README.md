# TOJ_Plus_Plus
=====

[![Build Status](https://travis-ci.org/ncfxy/TOJ_Plus_Plus.svg?branch=master)](https://travis-ci.org/ncfxy/TOJ_Plus_Plus)

这是一个基于缺陷定位和缺陷修复的toj项目
